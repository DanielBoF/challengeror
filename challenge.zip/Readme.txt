Para ejecutar el código se debe conectar a la base de datos (MySQL en mi caso)

Ejecutar el rails y leer en la terminal la dirección

Abrir la dirección en el navegador

importar el archivo .xslx 