class IngresosController < ApplicationController
  def index
  end

  def import
  end
end
class IngresosController < ApplicationController
  def index
    @ingresos = Ingreso.all
    @total_ingresos = @ingresos.sum("preciopz * numpz")
  end

  def import
    file = params[:file]
    if file.nil?
      redirect_to ingresos_path, alert: "Debes seleccionar un archivo"
      return
    end
    spreadsheet = Roo::Spreadsheet.open(file.path)
    header = spreadsheet.row(1)
    (2..spreadsheet.last_row).each do |i|
      row = Hash[[ header, spreadsheet.row(i) ].transpose]
      Ingreso.create!(
        cliente: row["Cliente"],
        descprod: row["descprod"],
        preciopz: row["preciopz"].to_f,
        numpz: row["numpz"].to_i,
        dirvend: row["dirvend"],
        namevend: row["namevend"]
      )
    end
    redirect_to ingresos_path, notice: "Archivo importado correctamente"
  end

  def clear_all
    Ingreso.delete_all
    redirect_to ingresos_path, notice: "Todos los registros fueron eliminados."
  end
end
