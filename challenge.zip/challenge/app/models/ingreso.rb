require "roo"

class Ingreso < ApplicationRecord
  def self.import(file)
    extension = File.extname(file.original_filename)
    spreadsheet =
      case extension
      when ".xlsx" then Roo::Excelx.new(file.path)
      when ".xls"  then Roo::Excel.new(file.path)
      when ".csv"  then Roo::CSV.new(file.path)
      else
        raise "Formato de archivo no soportado: #{extension}"
      end

    # Usa la primera hoja (por si hay varias)
    spreadsheet.default_sheet = spreadsheet.sheets.first
    puts "📘 Hoja activa: #{spreadsheet.default_sheet}"

    (2..spreadsheet.last_row).each do |i|
      row = spreadsheet.row(i).map { |v| v.is_a?(String) ? v.strip : v }
      puts "👉 Fila #{i}: #{row.inspect}"

      Ingreso.create(
        cliente:  row[0],
        descprod: row[1],
        preciopz: row[2].to_f,
        numpz:    row[3].to_i,
        dirvend:  row[4],
        namevend: row[5]
      )
    end
  end
end
