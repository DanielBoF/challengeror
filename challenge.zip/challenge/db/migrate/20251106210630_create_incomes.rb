class CreateIncomes < ActiveRecord::Migration[8.1]
  def change
    create_table :incomes do |t|
      t.string :cliente
      t.string :descprod
      t.decimal :preciopz, precision: 15, scale: 2
      t.integer :numpz
      t.string :dirvend
      t.string :namevend

      t.timestamps
    end
  end
end
