class CreateIngresos < ActiveRecord::Migration[8.1]
  def change
    create_table :ingresos do |t|
      t.string :cliente
      t.string :descprod
      t.decimal :preciopz
      t.integer :numpz
      t.string :dirvend
      t.string :namevend

      t.timestamps
    end
  end
end
