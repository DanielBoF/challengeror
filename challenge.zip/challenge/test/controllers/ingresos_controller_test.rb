require "test_helper"

class IngresosControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get ingresos_index_url
    assert_response :success
  end

  test "should get import" do
    get ingresos_import_url
    assert_response :success
  end
end
